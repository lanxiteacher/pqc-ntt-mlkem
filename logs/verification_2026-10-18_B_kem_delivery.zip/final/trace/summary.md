# ML-KEM-768 NTT transcript (software only)

KAT record 0; keygen=6, encaps=3, decaps=6; 15 calls / 3840 coefficients.

PASS: public compatible KAT; baseline/traced identical; deterministic extraction; all forward NTT calls agree with separately built original C oracle; three negative controls rejected.

No board or RTL replay has been performed. This does not implement complete ML-KEM on FPGA.
